import NavbarGrin from '../components/NavbarGrin'
import Presidente from '../components/Presidente';
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';


// pagina /presidenti
function PresidentiPage() {
  const [presidenti, setPresidenti] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadAllPresidenti = async () => {
    fetch('http://localhost:8081/presidenti')
        .then(res => res.json())
        .then(data => {
          setPresidenti(data);
          setLoading(false);
        })
        .catch(error => console.error("Errore nel caricamento dei dati:", error));
  }

  const navigate = useNavigate();
  const createNewPresidente = () => {
    navigate('/crea-un-nuovo-account');
  }

  useEffect(() => loadAllPresidenti, []); // Non ha dipendenze, eseguito ad ogni render
  
  if(loading) return <p>LOADING...</p>
  return (
    <>
      <NavbarGrin />
      <h1 className='text-blue-800'>Elenco dei presidenti</h1>
      <div className="flex space-x-4 p-4 items-center justify-center">
        <p className="text-xl">Azioni: </p>
        <button className="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-700" onClick={createNewPresidente}> Crea nuovo account</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-5 p-5">
            <div className="font-semibold text-lg text-blue-800 p-2 border-b-2 border-blue-800">Nome</div>
            <div className="font-semibold text-lg text-blue-800 p-2 border-b-2 border-blue-800">Cognome</div>
            <div className="font-semibold text-lg text-blue-800 p-2 border-b-2 border-blue-800">Email</div>
            <div className="font-semibold text-lg text-blue-800 p-2 border-b-2 border-blue-800">Università</div>
            <div className="font-semibold text-lg text-blue-800 p-2 border-b-2 border-blue-800"></div>

            {presidenti.map(p => (
                <Presidente key={p.idPresidente} presidente={p}/>
            ))}           
        </div>
    </>
  )
}

export default PresidentiPage