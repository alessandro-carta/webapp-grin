import NavbarGrin from "../components/NavbarGrin";
import FormNewPresidente from "../components/FormNewPresidente";

function CreateNewPresidentePage() {

    return(
        <>
            <NavbarGrin />
            <h1 className='text-blue-800'>Crea un nuovo account</h1>
            <FormNewPresidente />
        </>
    )
    
}

export default CreateNewPresidentePage;