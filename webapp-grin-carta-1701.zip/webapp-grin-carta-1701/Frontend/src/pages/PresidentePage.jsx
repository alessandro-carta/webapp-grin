import NavbarGrin from '../components/NavbarGrin';
import { useParams } from "react-router-dom";
import React, { useState, useEffect } from 'react';
import FormUpdatePresidente from '../components/FormUpdatePresidente';

function PresidentePage() {
    const [presidente, setPresidente] = useState();
    const { idPresidente } = useParams();
    const [loading, setLoading] = useState(true);
    const [update, setUpdate] = useState(false);
    const [message, setMessage] = useState(false);

    const loadPresidente = async () => {
        fetch(`http://localhost:8081/presidenti/${idPresidente}`)
            .then(res => res.json())
            .then(data => {
              setPresidente(data);
              setLoading(false);
            })
            .catch(error => console.error("Errore nel caricamento dei dati:", error));
      }

    useEffect( () => loadPresidente, [idPresidente]);

    if(loading) return <p>LOADING...</p>

    if(!update){
        return (
            <>
                <NavbarGrin />
                <h1 className='text-blue-800'>{presidente.Università}</h1>
                <p className="text-xl">Presidente: {presidente.Nome} {presidente.Cognome}</p>
                <p className="text-xl">Contatto: {presidente.Email}</p>
                <p className="text-xl">Password per primo accesso: {presidente.FirstPassword}</p>
                <p className="text-xl">Stato account: {presidente.Attivo == 1 ? "Attivo" : "Disattivato"}</p>
                <div className="flex space-x-4 p-4 items-center justify-center">
                    <p className="text-xl">Azioni: </p>
                    <button className="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-700" onClick={() => {setUpdate(true)}}> Modifica account </button>
                    { presidente.Attivo == 1 ? 
                        <button className="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-700" onClick={() => {alert('Disabilitato')}}> Disabilita account </button> :
                        <button className="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-700" onClick={() => {alert('Riattivato')}}> Riattiva account </button> }
                </div>
            </>
        )
    }
    else{
        return (
            <>
                <FormUpdatePresidente presidente={presidente}/>
                <div className="flex space-x-4 p-4 items-center justify-center">
                    <p className="text-xl">Azioni: </p>
                    <button className="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-700" onClick={() => {setUpdate(false)}}> Annulla </button>
                </div>

            </>
        )
    }
}

export default PresidentePage;