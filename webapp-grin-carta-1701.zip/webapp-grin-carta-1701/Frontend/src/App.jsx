import './App.css'
import NavbarGrin from './components/NavbarGrin'

function App() {

  return (
    <>
      <NavbarGrin />
      <h1 className='text-blue-800'>Homepage</h1>
    </>
  )
}

export default App
