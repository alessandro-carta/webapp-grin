import { Link } from "react-router-dom";


function NavbarGrin(){

    // restitusce la barra di navigazione dell'amministrazione
    return (
        <div className="container mx-auto flex flex-col justify-between items-center space-x-6">
            <div className="space-x-6">
                <Link to={`/`} className="text-blue-800 hover:text-gray-300"> Homepage </Link>
                <Link to={`/presidenti`} className="text-blue-800 hover:text-gray-300"> Account presidenti </Link>
            </div>
        </div>
    )

}

export default NavbarGrin;