import { useState } from "react";
import { v4 as uuidv4 } from 'uuid';
import { Link, useNavigate } from "react-router-dom";

function FormNewPresidente() {

    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        Nome: "",
        Cognome: "",
        Email: "",
        Università: ""
    })

    const [formErrors, setFormErros] = useState({
        Nome: "",
        Cognome: "",
        Email: "",
        Università: ""
    })

    const checkNome = () => {
        if(!formData.Nome){
            setFormErros({
                ...formErrors,
                Nome: "Campo obbligatorio"
            })
            return false;
        }
        return true;
    }

    const checkCognome = () => {
        if(!formData.Cognome){
            setFormErros({
                ...formErrors,
                Cognome: "Campo obbligatorio"
            })
            return false;
        }
        return true;
    }

    const checkEmail = () => {
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        if(!formData.Email || !emailPattern.test(formData.Email)){
            setFormErros({
                ...formErrors,
                Email: "Inserisci email valida"
            })
            return false;
        }
        return true;
    }

    const checkUniversità = () => {
        if(!formData.Università){
            setFormErros({
                ...formErrors,
                Università: "Campo obbligatorio"
            })
            return false;
        }
        return true;
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        if(checkNome() && checkCognome() && checkEmail() && checkUniversità()){
            const data = {...formData, idPresidente: uuidv4()};
            const response = await fetch(`http://localhost:8081/addPresidente`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (response.ok) {
                navigate('/presidenti');
            }
        }

    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });

        setFormErros({
            ...formErrors,
            [name]: ""
        });
    }

    return(
        <>
            <div className="w-full max-w-md bg-gray-100 p-8 rounded-lg">
                <form onSubmit={handleSubmit}>
                    {/* Nome */}
                    <div className="mb-4">
                        <label htmlFor="Nome" className="block text-sm font-medium text-gray-700">Nome*</label>
                        <input
                            type="text"
                            id="Nome"
                            name="Nome"
                            value={formData.Nome}
                            onChange={handleChange}
                            className="mt-1 p-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        {formErrors.Nome && <p style={{ color: 'red' }}>{formErrors.Nome}</p>}
                    </div>
                    {/* Cognome */}
                    <div className="mb-4">
                        <label htmlFor="Cognome" className="block text-sm font-medium text-gray-700">Cognome*</label>
                        <input
                            type="text"
                            id="Cognome"
                            name="Cognome"
                            value={formData.Cognome}
                            onChange={handleChange}
                            className="mt-1 p-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        {formErrors.Cognome && <p style={{ color: 'red' }}>{formErrors.Cognome}</p>}
                    </div>
                    {/* Email */}
                    <div className="mb-4">
                        <label htmlFor="Email" className="block text-sm font-medium text-gray-700">Email*</label>
                        <input
                            type="text"
                            id="Email"
                            name="Email"
                            value={formData.Email}
                            onChange={handleChange}
                            className="mt-1 p-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        {formErrors.Email && <p style={{ color: 'red' }}>{formErrors.Email}</p>}
                    </div>
                    {/* Università */}
                    <div className="mb-4">
                        <label htmlFor="Università" className="block text-sm font-medium text-gray-700">Università*</label>
                        <input
                            type="text"
                            id="Università"
                            name="Università"
                            value={formData.Università}
                            onChange={handleChange}
                            className="mt-1 p-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        {formErrors.Università && <p style={{ color: 'red' }}>{formErrors.Università}</p>}
                    </div>
                    {/* Bottone di invio e annulla */}
                    <div className="mb-4">
                        <button
                            type="submit"
                            className="w-full bg-blue-500 text-white p-2 rounded-md hover:bg-blue-700"
                        >
                            Crea un nuovo account
                        </button>

                        <Link
                            className="text-blue-500 hover:text-blue-700"
                            to={'/presidenti'}
                        >
                            Annulla
                        </Link>
                    </div>
                </form>
            </div>
            
        </>
    )
    
}

export default FormNewPresidente;