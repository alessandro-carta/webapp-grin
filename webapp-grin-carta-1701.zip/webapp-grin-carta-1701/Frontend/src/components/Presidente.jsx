import React from 'react';
import { Link } from 'react-router-dom';

function Presidente(props) {
    return (
        <>
            <div className="p-2 border-b border-gray-300">{props.presidente.Nome}</div>
            <div className="p-2 border-b border-gray-300">{props.presidente.Cognome}</div>
            <div className="p-2 border-b border-gray-300">{props.presidente.Email}</div>
            <div className="p-2 border-b border-gray-300">{props.presidente.Università}</div>
            <div className="p-2 underline border-b border-gray-300">
                <Link to={`/presidenti/${props.presidente.idPresidente}`} key={props.presidente.idPresidente}> Visualizza </Link>
            </div >
        </>
    )
}
  
export default Presidente;