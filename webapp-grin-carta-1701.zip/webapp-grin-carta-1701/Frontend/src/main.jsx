import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { createBrowserRouter, Router, RouterProvider } from 'react-router-dom'
import PresidentiPage from './pages/PresidentiPage.jsx'
import PresidentePage from './pages/PresidentePage.jsx'
import CreateNewPresidentePage from './pages/CreateNewPresidentePage.jsx'

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />
  },
  {
    path: "presidenti",
    element: <PresidentiPage />
  },
  {
    path: "presidenti/:idPresidente",
    element: <PresidentePage />
  },
  {
    path: "crea-un-nuovo-account",
    element: <CreateNewPresidentePage />
  }
]
)

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
