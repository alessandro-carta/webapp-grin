import express from "express"
import cors from "cors"
import { getPresidenti, addPresidente, getPresidente, updatePresidente} from "./funPresidenti.js";

const app = express();
app.use(cors());
app.use(express.json());
app.listen(8081, () => {
    console.log("Server in ascolto sulla porta 8081");
})
app.get("/", (req, res) => {
    return res.json("Test backend");
})






app.get("/presidenti", async (req, res) => {
    const presidenti = await getPresidenti();
    res.json(presidenti);
})
app.get("/presidenti/:idPresidente", async (req, res) => {
    const idPresidente = req.params.idPresidente;
    const presidente = await getPresidente(idPresidente);
    res.json(presidente);
})
app.post("/addPresidente", async (req, res) => {
    const {idPresidente, Nome, Cognome, Email, Università } = req.body;
    const result = await addPresidente(idPresidente, Nome, Cognome, Email, Università);
    res.status(201).json(result);
})
app.put("/updatePresidente", async (req, res) => {
    const {idPresidente, Nome, Cognome, Email, Università } = req.body;
    const result = await updatePresidente(idPresidente, Nome, Cognome, Email, Università);
    res.status(200).json(result);
})
